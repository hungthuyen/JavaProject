package com.example.demospeech;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainViewModel extends ViewModel {
    private MutableLiveData<Integer> state_light;
    private MutableLiveData<Integer> state_fan;

    private final DatabaseReference ref = FirebaseDatabase.getInstance().getReference();

    public  MainViewModel(){
        state_fan = new MutableLiveData<>();
        state_light = new MutableLiveData<>();

        ref.child("light").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int light = dataSnapshot.getValue(Integer.class);
                state_light.setValue(light);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        ref.child("fan").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
               int fan = dataSnapshot.getValue(Integer.class);
                state_fan.setValue(fan);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }
    public LiveData<Integer> getStateLight(){
        return state_light;
    }

    public LiveData<Integer> getStateFan(){
        return state_fan;
    }

}
