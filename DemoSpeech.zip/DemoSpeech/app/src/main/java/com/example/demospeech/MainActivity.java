package com.example.demospeech;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_SPEECH_INPUT = 1000 ;
    private TextView tvDisplay ;
    private ImageButton btnVoice;
    private Button btnLight, btnFan;
    private MainViewModel mainViewModel;

    private final DatabaseReference ref_light = FirebaseDatabase.getInstance().getReference().child("light");
    private final DatabaseReference ref_fan = FirebaseDatabase.getInstance().getReference().child("fan");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainViewModel = ViewModelProviders.of(this).get(MainViewModel.class);

        mainViewModel.getStateFan().observe(this, new Observer<Integer>() {
            @Override
            public void onChanged(Integer temp) {
                String text = temp == 1 ? "ON" : "OFF";
                int bg = temp == 1 ? R.drawable.button_on : R.drawable.button_off;
                btnFan.setText(text);
                btnFan.setBackgroundResource(bg);
            }
        });

        mainViewModel.getStateLight().observe(this, new Observer<Integer>() {
            @Override
            public void onChanged(Integer temp) {
                String text = temp == 1 ? "ON" : "OFF";
                int bg = temp == 1 ? R.drawable.button_on : R.drawable.button_off;
                btnLight.setText(text);
                btnLight.setBackgroundResource(bg);
            }
        });

        tvDisplay = (TextView) findViewById(R.id.tvDisplay);
        btnVoice = (ImageButton) findViewById(R.id.btnVoice);
        btnFan = (Button) findViewById(R.id.btnFan);
        btnLight = (Button) findViewById(R.id.btnLight);
        btnVoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               speak();
            }
        });;

    }

    private void speak() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Hi speak something");
        try {
            startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT);
        }
        catch (Exception e){

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case REQUEST_CODE_SPEECH_INPUT:
                if(resultCode == RESULT_OK && null!=data){
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    String text = result.get(0);

                    text = text.trim();
                    text = text.toLowerCase();
                    tvDisplay.setText(text);
                    if(text.equals("tắt đèn") || text.equals("turn off the light"))  {
                       if(btnLight.getText().equals("ON")){
                           btnLight.setText("OFF");
                           btnLight.setBackgroundResource(R.drawable.button_off);
                           ref_light.setValue(0);
                       }
                    }

                    if(text.equals("tắt quạt") || text.equals("turn off the fan")) {
                        if(btnFan.getText().equals("ON")){
                            btnFan.setText("OFF");
                            btnFan.setBackgroundResource(R.drawable.button_off);
                            ref_fan.setValue(0);
                        }
                    }

                    if(text.equals("bật quạt") || text.equals("turn on the fan")) {
                        if(btnFan.getText().equals("OFF")){
                            btnFan.setText("ON");
                            btnFan.setBackgroundResource(R.drawable.button_on);
                            ref_fan.setValue(1);
                        }
                    }
                    if(text.equals("bật đèn") || text.equals("turn on the light")) {
                        if(btnLight.getText().equals("OFF")){
                            btnLight.setText("ON");
                            btnLight.setBackgroundResource(R.drawable.button_on);
                            ref_light.setValue(1);
                        }
                    }
                }
        }
    }
}
